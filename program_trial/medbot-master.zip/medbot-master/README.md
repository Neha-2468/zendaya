# medbot
MedBot is a virtual medical assistant with whom users can chat with and explain their symptoms. After their explanation, MedBot will analyze the symptoms and predict the ailments. 
